-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.28-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for teesasql
CREATE DATABASE IF NOT EXISTS `teesasql` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `teesasql`;

-- Dumping structure for table teesasql.about_me
CREATE TABLE IF NOT EXISTS `about_me` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table teesasql.about_me: ~1 rows (approximately)
DELETE FROM `about_me`;
/*!40000 ALTER TABLE `about_me` DISABLE KEYS */;
INSERT INTO `about_me` (`id`, `title`, `description`) VALUES
	(1, 'About Me', 'A passionate informatics student stepping into the world of photography and design. Although my experience in these fields is still limited, I am driven by a strong desire to learn and grow. I believe that every small step is an opportunity for progress. Currently, I’m building my portfolio while exploring new creative skills beyond my comfort zone. I’m ready to embrace challenges and opportunities to enhance my abilities in photography and design.');
/*!40000 ALTER TABLE `about_me` ENABLE KEYS */;

-- Dumping structure for table teesasql.contact
CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table teesasql.contact: ~0 rows (approximately)
DELETE FROM `contact`;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` (`id`, `full_name`, `email`, `phone_number`, `message`) VALUES
	(15, 'teesa', 'teesa@gmail.com', '08123123123', 'hai!');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;

-- Dumping structure for table teesasql.contact_info
CREATE TABLE IF NOT EXISTS `contact_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table teesasql.contact_info: ~1 rows (approximately)
DELETE FROM `contact_info`;
/*!40000 ALTER TABLE `contact_info` DISABLE KEYS */;
INSERT INTO `contact_info` (`id`, `address`, `phone`, `email`) VALUES
	(1, 'Kebayoran Lama Selatan, Jakarta Selatan', '081807013829', 'teesa@gmail.com');
/*!40000 ALTER TABLE `contact_info` ENABLE KEYS */;

-- Dumping structure for table teesasql.education
CREATE TABLE IF NOT EXISTS `education` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institution_name` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `duration` varchar(50) NOT NULL,
  `major` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table teesasql.education: ~2 rows (approximately)
DELETE FROM `education`;
/*!40000 ALTER TABLE `education` DISABLE KEYS */;
INSERT INTO `education` (`id`, `institution_name`, `image_path`, `duration`, `major`) VALUES
	(1, 'Universitas Pembangunan Jaya', 'images/upj.jpg', '2023-Now', 'Program Studi Informatika'),
	(2, 'SMAN 82 Jakarta', 'images/sma.jpg', '2019-2022', 'IPA');
/*!40000 ALTER TABLE `education` ENABLE KEYS */;

-- Dumping structure for table teesasql.gallery
CREATE TABLE IF NOT EXISTS `gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_path` varchar(255) NOT NULL,
  `alt_text` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table teesasql.gallery: ~8 rows (approximately)
DELETE FROM `gallery`;
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;
INSERT INTO `gallery` (`id`, `image_path`, `alt_text`) VALUES
	(1, 'images/gallery1.jpg', 'Gallery 1'),
	(2, 'images/gallery2.jpg', 'Gallery 2'),
	(3, 'images/gallery3.jpg', 'Gallery 3'),
	(4, 'images/gallery4.jpg', 'Gallery 4'),
	(5, 'images/GALLERY5.jpg', 'Gallery 5'),
	(6, 'images/GALLERY6.jpg', 'Gallery 6'),
	(7, 'images/GALLERY7.jpg', 'Gallery 7'),
	(8, 'images/GALLERY8.jpg', 'Gallery 8');
/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;

-- Dumping structure for table teesasql.skills
CREATE TABLE IF NOT EXISTS `skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `skill_name` varchar(100) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table teesasql.skills: ~4 rows (approximately)
DELETE FROM `skills`;
/*!40000 ALTER TABLE `skills` DISABLE KEYS */;
INSERT INTO `skills` (`id`, `skill_name`, `image_path`) VALUES
	(1, 'Writing', 'images/logo1.jpg'),
	(2, 'Reading', 'images/logo2.jpg'),
	(3, 'Team Work', 'images/logo3.jpg'),
	(4, 'Project', 'images/logo1.jpg');
/*!40000 ALTER TABLE `skills` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
