<?php $conn = new mysqli("localhost", "root", "", "teesasql") ?>
<!DOCTYPE html>
<html lang="en">

<head>
   <!-- basic -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <!-- mobile metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="initial-scale=1, maximum-scale=1">
   <!-- site metas -->
   <title>Contact Me</title>
   <meta name="keywords" content="">
   <meta name="description" content="">
   <meta name="author" content="">
   <!-- bootstrap css -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <!-- style css -->
   <link rel="stylesheet" href="css/style.css">
   <!-- Responsive-->
   <link rel="stylesheet" href="css/responsive.css">
   <!-- fevicon -->
   <link rel="icon" href="" type="image/gif" />
   <!-- Scrollbar Custom CSS -->
   <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
   <!-- Tweaks for older IEs-->
   <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
   <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<!-- body -->

<body class="main-layout">
   <!-- loader  -->
   <!-- <div class="loader_bg">
      <div class="loader"><img src="images/loading.gif" alt="#" /></div>
   </div> -->
   <!-- end loader -->
   <!-- header -->
   <header>
      <!-- header inner -->
      <div class="header">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo">
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                  <nav class="navigation navbar navbar-expand-md navbar-dark ">
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                           <li class="nav-item ">
                              <a class="nav-link" href="home.php">Home</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="about.php">About</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="education.php">Education</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="skills.php">Skill</a>
                           </li>
                           <li class="nav-item active">
                              <a class="nav-link" href="contact.php">Contact Me</a>
                           </li>
                        </ul>
                     </div>
                  </nav>
               </div>
               <div class="col-md-2">
                  <ul class="social_icon">
                     <li><a href="https://www.instagram.com/sh_.ahnaz?igsh=cHJlYnVjc2UzMndn"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- end header inner -->
   <!-- end header -->
   <div class="back_re">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="title">
                  <h2>Get In Touch</h2>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!--  contact -->
   <div class="contact">
      <div class="container">
         <div class="row">
            <div class="col-md-6 offset-md-3">
               <?php

               if ($_SERVER["REQUEST_METHOD"] == "POST") {
                  // Get data from form
                  $fullname = $_POST['full_name'];
                  $email = $_POST['email'];
                  $number = $_POST['phone_number'];
                  $message = $_POST['message'];

                  // Prepare SQL query
                  $stmt = $conn->prepare("INSERT INTO contact (full_name, email, phone_number, message) VALUES (?, ?, ?, ?)");
                  $stmt->bind_param("ssss", $fullname, $email, $number, $message);

                  if ($stmt->execute()) {
                     echo "<script>
                     Swal.fire({
                        title: 'Success!',
                        text: 'Your message has been sent successfully.',
                        icon: 'success',
                        confirmButtonText: 'OK'
                     });
                  </script>";
                  } else {
                     echo "<script>
                     Swal.fire({
                        title: 'Error!',
                        text: 'There was an error sending your message.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                     });
                  </script>";
                  }

                  // Close the prepared statement
                  $stmt->close();
               }
               ?>
               <form id="request" class="main_form" method="POST" action="contact.php">
                  <div class="row">
                     <div class="col-md-12">
                        <input class="contactus" placeholder="Full Name" type="text" name="full_name" required>
                     </div>
                     <div class="col-md-12">
                        <input class="contactus" placeholder="Email" type="email" name="email" required>
                     </div>
                     <div class="col-md-12">
                        <input class="contactus" placeholder="Phone Number" type="text" name="phone_number" required>
                     </div>
                     <div class="col-md-12">
                        <textarea class="textarea" placeholder="Message" name="message" required></textarea>
                     </div>
                     <div class="col-md-12">
                        <button class="send_btn" type="submit">Send</button>
                     </div>
                  </div>
               </form>

               <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
               <script>
                  $(document).ready(function() {
                     $('form').on('submit', function(e) {
                        e.preventDefault();
                        var formData = $(this).serialize();

                        $.ajax({
                           type: 'POST',
                           url: 'contact.php',
                           data: formData,
                           success: function(response) {
                              Swal.fire({
                                 title: 'Success!',
                                 text: 'Your message has been sent successfully.',
                                 icon: 'success',
                                 confirmButtonText: 'OK'
                              });
                              $('form')[0].reset();
                           },
                           error: function() {
                              Swal.fire({
                                 title: 'Error!',
                                 text: 'There was an error sending your message.',
                                 icon: 'error',
                                 confirmButtonText: 'OK'
                              });
                           }
                        });
                     });
                  });
               </script>


            </div>
         </div>
      </div>
      <div class="container-fluid">
         <div class="row">
            <div class="col-md-12">
               <div class="map_main">
                  <div class="map-responsive">
                     <iframe src="https://www.google.com/maps/embed/v1/place?key=AIzaSyA0s1a7phLN0iaD6-UE7m4qP-z21pH0eSc&amp;q=Eiffel+Tower+Paris+France" width="600" height="386" frameborder="0" style="border:0; width: 100%;" allowfullscreen=""></iframe>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- end contact -->
   <!--  footer -->
   <footer>
      <div class="footer">
         <div class="container">
            <?php
            $sql = "SELECT * FROM contact_info LIMIT 1";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
               $row = $result->fetch_assoc();
               $address = $row['address'];
               $phone = $row['phone'];
               $email = $row['email'];
            } else {
               $address = 'Address not available';
               $phone = 'Phone not available';
               $email = 'Email not available';
            }

            $conn->close();
            ?>

            <div class="row">
               <div class="col-md-12">
                  <ul class="conta">
                     <li><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo $address; ?></li>
                     <li><i class="fa fa-phone" aria-hidden="true"></i> Call : <?php echo $phone; ?></li>
                     <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="#"><?php echo $email; ?></a></li>
                  </ul>
               </div>
               <div class=" col-md-3 col-sm-6">
                  <h3>About </h3>
                  <p class="variat">Passionate about creating impactful experiences through innovative solutions.</p>
               </div>
               <div class=" col-md-3 col-sm-6">
                  <h3>Education </h3>
                  <p class="variat"> Equipped with knowledge and skills from diverse learning experiences.</p>
               </div>
               <div class="col-md-2 col-sm-6">
                  <h3>Useful Link</h3>
                  <ul class="link_menu">
                     <li><a href="home.php">Home</a></li>
                     <li><a href="about.php"> About</a></li>
                     <li><a href="education.php">Education</a></li>
                     <li><a href="skills.php">Skills</a></li>
                     <li class="active"><a href="contact.php">Contact Us</a></li>
                  </ul>
               </div>
               <div class="col-md-4 col-sm-6">
                  <h3>Subscribe</h3>
                  <form class="bottom_form">
                     <a class="right_btn" href="Javascript:void(0)"> <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                     <input class="enter" placeholder="Enter your email" type="text" name="Enter your email">
                     <p>Thank you for subscribe </p>
                  </form>
               </div>
            </div>
         </div>

      </div>
   </footer>


   <!-- Include Toastify CSS -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastify-js/1.11.2/Toastify.min.css">

   <!-- Include Toastify JS -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/toastify-js/1.11.2/Toastify.min.js"></script>


   <!-- end footer -->
   <!-- Javascript files-->
   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="js/jquery-3.0.0.min.js"></script>
   <!-- sidebar -->
   <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
   <script src="js/custom.js"></script>
</body>

</html>