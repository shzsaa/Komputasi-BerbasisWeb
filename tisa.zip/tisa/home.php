<?php $conn = new mysqli("localhost", "root", "", "teesasql") ?>
<!DOCTYPE html>
<html lang="en">

<head>
   <!-- basic -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <!-- mobile metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="initial-scale=1, maximum-scale=1">
   <!-- site metas -->
   <title>Teesa</title>
   <meta name="keywords" content="">
   <meta name="description" content="">
   <meta name="author" content="">
   <!-- bootstrap css -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <!-- style css -->
   <link rel="stylesheet" href="css/style.css">
   <!-- Responsive-->
   <link rel="stylesheet" href="css/responsive.css">
   <!-- fevicon -->
   <link rel="icon" href="images/fevicon.png" type="image/gif" />
   <!-- Scrollbar Custom CSS -->
   <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
   <!-- Tweaks for older IEs-->
   <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
   <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->

<body class="main-layout">
   <header>
      <!-- header inner -->
      <div class="header">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo">
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                  <nav class="navigation navbar navbar-expand-md navbar-dark ">
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                           <li class="nav-item active">
                              <a class="nav-link" href="home.php">Home</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="about.php">About</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="education.php">Education</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="skills.php">Skill</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="contact.php">Contact Me</a>
                           </li>
                        </ul>
                     </div>
                  </nav>
               </div>
               <div class="col-md-2">
                  <ul class="social_icon">
                     <li><a href="https://www.instagram.com/sh_.ahnaz?igsh=cHJlYnVjc2UzMndn"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- end header inner -->
   <!-- end header -->
   <!-- banner -->
   <section class="banner_main">
      <div id="myCarousel" class="carousel slide banner1" data-ride="carousel">
         <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
         </ol>
         <div class="carousel-inner">
            <!-- Slide 1 -->
            <div class="carousel-item active">
               <div class="container-fluid">
                  <div class="carousel-caption relative">
                     <div class="row d_flex">
                        <div class="col-md-6">
                           <img class="bann_img" src="images/tisa.jpg" alt="#" />
                        </div>
                        <div class="col-md-6">
                           <span>01/02</span>
                           <h1>Teesa Shahnaz Portofolio</h1>
                           <p>Where Creativity Meets Strategy – Dive Into My Portfolio</p>
                           <a class="get_btn" href="Javascript:void(0)" role="button">Get To Know</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <!-- Slide 2: Gallery with 4 photos -->
            <div class="carousel-item">
               <div class="container-fluid">
                  <div class="carousel-caption relative">
                     <?php
                     // Query untuk mengambil data dari tabel gallery
                     $query = "SELECT * FROM gallery";
                     $result = $conn->query($query);

                     // Cek apakah ada data
                     if ($result->num_rows > 0) {
                        echo '<div class="row d_flex">';
                        // Loop untuk menampilkan gambar dari hasil query
                        while ($row = $result->fetch_assoc()) {
                           echo '<div class="col-md-3">';
                           echo '<img class="gallery_img" src="' . htmlspecialchars($row['image_path']) . '" alt="' . htmlspecialchars($row['alt_text']) . '" />';
                           echo '</div>';
                        }
                        echo '</div>';
                     } else {
                        echo '<p>Tidak ada gambar di galeri.</p>';
                     }
                     ?>


                     <div class="row">
                        <div class="col-md-12 text-center mt-5">
                           <span>02/02</span>
                           <h1>Shahnaz's Gallery</h1>
                           <p>Explore the creative journey through visuals</p>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
               <i class="fa fa-long-arrow-left" aria-hidden="true"></i>
               <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
               <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
               <span class="sr-only">Next</span>
            </a>
         </div>
      </div>
   </section>

   <!-- end banner -->
   <!--  footer -->
   <footer>
      <div class="footer">
         <div class="container">
            <?php
            $sql = "SELECT * FROM contact_info LIMIT 1";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
               $row = $result->fetch_assoc();
               $address = $row['address'];
               $phone = $row['phone'];
               $email = $row['email'];
            } else {
               $address = 'Address not available';
               $phone = 'Phone not available';
               $email = 'Email not available';
            }

            $conn->close();
            ?>

            <div class="row">
               <div class="col-md-12">
                  <ul class="conta">
                     <li><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo $address; ?></li>
                     <li><i class="fa fa-phone" aria-hidden="true"></i> Call : <?php echo $phone; ?></li>
                     <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="#"><?php echo $email; ?></a></li>
                  </ul>
               </div>
               <div class=" col-md-3 col-sm-6">
                  <h3>About </h3>
                  <p class="variat">Passionate about creating impactful experiences through innovative solutions.</p>
               </div>
               <div class=" col-md-3 col-sm-6">
                  <h3>Education </h3>
                  <p class="variat"> Equipped with knowledge and skills from diverse learning experiences.</p>
               </div>
               <div class="col-md-2 col-sm-6">
                  <h3>Useful Link</h3>
                  <ul class="link_menu">
                     <li><a href="home.php">Home</a></li>
                     <li><a href="about.php"> About</a></li>
                     <li><a href="education.php">Education</a></li>
                     <li><a href="skills.php">Skills</a></li>
                     <li class="active"><a href="contact.php">Contact Us</a></li>
                  </ul>
               </div>
               <div class="col-md-4 col-sm-6">
                  <h3>Subscribe</h3>
                  <form class="bottom_form">
                     <a class="right_btn" href="Javascript:void(0)"> <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                     <input class="enter" placeholder="Enter your email" type="text" name="Enter your email">
                     <p>Thank you for subscribe </p>
                  </form>
               </div>
            </div>
         </div>

      </div>
   </footer>
   <!-- end footer -->
   <!-- Javascript files-->
   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="js/jquery-3.0.0.min.js"></script>
   <!-- sidebar -->
   <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
   <script src="js/custom.js"></script>
</body>

</html>