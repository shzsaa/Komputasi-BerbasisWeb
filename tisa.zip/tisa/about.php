<?php $conn = new mysqli("localhost", "root", "", "teesasql") ?>
<!DOCTYPE html>
<html lang="en">

<head>
   <!-- basic -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <!-- mobile metas -->
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <meta name="viewport" content="initial-scale=1, maximum-scale=1">
   <!-- site metas -->
   <title>Tea - My Porto</title>
   <meta name="keywords" content="">
   <meta name="description" content="">
   <meta name="author" content="">
   <!-- bootstrap css -->
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <!-- style css -->
   <link rel="stylesheet" href="css/style.css">
   <!-- Responsive-->
   <link rel="stylesheet" href="css/responsive.css">
   <!-- fevicon -->
   <link rel="icon" href="images/fevicon.png" type="image/gif" />
   <!-- Scrollbar Custom CSS -->
   <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
   <!-- Tweaks for older IEs-->
   <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
   <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
</head>
<!-- body -->

<body class="main-layout">
   <!-- header -->
   <header>
      <!-- header inner -->
      <div class="header">
         <div class="container-fluid">
            <div class="row">
               <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                  <div class="full">
                     <div class="center-desk">
                        <div class="logo">
                        </div>
                     </div>
                  </div>
               </div>
               <div class="col-xl-7 col-lg-7 col-md-9 col-sm-9">
                  <nav class="navigation navbar navbar-expand-md navbar-dark ">
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse" id="navbarsExample04">
                        <ul class="navbar-nav mr-auto">
                           <li class="nav-item">
                              <a class="nav-link" href="home.php">Home</a>
                           </li>
                           <li class="nav-item active">
                              <a class="nav-link" href="about.php">About</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="education.php">Education</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="skills.php">Skill</a>
                           </li>
                           <li class="nav-item">
                              <a class="nav-link" href="contact.php">Contact Me</a>
                           </li>
                        </ul>
                     </div>
                  </nav>
               </div>
               <div class="col-md-2">
                  <ul class="social_icon">
                     <li><a href="https://www.instagram.com/sh_.ahnaz?igsh=cHJlYnVjc2UzMndn"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- end header inner -->
   <!-- end header -->
   <div class="back_re">
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="title">
                  <h2>Get To Know Me </h2>
               </div>
            </div>
         </div>
      </div>
   </div>

   <!-- about -->
   <div class="about slin2">
      <div class="container">
         <div class="row d_flex">
            <?php
            // Query untuk mengambil data deskripsi dari tabel about_me
            $query = "SELECT * FROM about_me WHERE id = 1";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
               $row = $result->fetch_assoc(); // Ambil satu baris data
               echo '<div class="col-md-6">';
               echo '<div class="titlepage">';
               echo '<h2>' . htmlspecialchars($row['title']) . '</h2>';
               echo '<p>' . htmlspecialchars($row['description']) . '</p>';
               echo '<a class="read_more" href="Javascript:void(0)"> Read More</a>';
               echo '</div>';
               echo '</div>';
            } else {
               echo '<p>Deskripsi belum tersedia.</p>';
            }
            ?>

            <div class="col-md-6">
               <div class="about_img">
                  <figure><img src="images/hitam.jpg" alt="#" /></figure>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!-- end about -->

   <!--  footer -->
   <footer>
      <div class="footer">
         <div class="container">
            <?php
            $sql = "SELECT * FROM contact_info LIMIT 1";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
               $row = $result->fetch_assoc();
               $address = $row['address'];
               $phone = $row['phone'];
               $email = $row['email'];
            } else {
               $address = 'Address not available';
               $phone = 'Phone not available';
               $email = 'Email not available';
            }

            $conn->close();
            ?>

            <div class="row">
               <div class="col-md-12">
                  <ul class="conta">
                     <li><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo $address; ?></li>
                     <li><i class="fa fa-phone" aria-hidden="true"></i> Call : <?php echo $phone; ?></li>
                     <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="#"><?php echo $email; ?></a></li>
                  </ul>
               </div>
               <div class=" col-md-3 col-sm-6">
                  <h3>About </h3>
                  <p class="variat">Passionate about creating impactful experiences through innovative solutions.</p>
               </div>
               <div class=" col-md-3 col-sm-6">
                  <h3>Education </h3>
                  <p class="variat"> Equipped with knowledge and skills from diverse learning experiences.</p>
               </div>
               <div class="col-md-2 col-sm-6">
                  <h3>Useful Link</h3>
                  <ul class="link_menu">
                     <li><a href="home.php">Home</a></li>
                     <li><a href="about.php"> About</a></li>
                     <li><a href="education.php">Education</a></li>
                     <li><a href="skills.php">Skills</a></li>
                     <li class="active"><a href="contact.php">Contact Us</a></li>
                  </ul>
               </div>
               <div class="col-md-4 col-sm-6">
                  <h3>Subscribe</h3>
                  <form class="bottom_form">
                     <a class="right_btn" href="Javascript:void(0)"> <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
                     <input class="enter" placeholder="Enter your email" type="text" name="Enter your email">
                     <p>Thank you for subscribe </p>
                  </form>
               </div>
            </div>
         </div>

      </div>
   </footer>
   <!-- end footer -->
   <!-- Javascript files-->
   <script src="js/jquery.min.js"></script>
   <script src="js/bootstrap.bundle.min.js"></script>
   <script src="js/jquery-3.0.0.min.js"></script>
   <!-- sidebar -->
   <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
   <script src="js/custom.js"></script>
</body>

</html>